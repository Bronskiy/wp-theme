<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_image_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_image_theme_setup' );
	function booklovers_sc_image_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_image_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_image_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_image id="unique_id" src="image_url" width="width_in_pixels" height="height_in_pixels" title="image's_title" align="left|right"]
*/

if (!function_exists('booklovers_sc_image')) {	
	function booklovers_sc_image($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"align" => "",
			"shape" => "square",
			"src" => "",
			"url" => "",
			"icon" => "",
			"link" => "",
			"shadow" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => "",
			"width" => "",
			"height" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= booklovers_get_css_dimensions_from_values($width, $height);
		$css .= ($shadow == 'yes' ? ' box-shadow: 0px 3px 10px 0px #adadab; -webkit-box-shadow: 0px 3px 10px 0px #adadab; ' : '');
		$src = $src!='' ? $src : $url;
		if ($src > 0) {
			$attach = wp_get_attachment_image_src( $src, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$src = $attach[0];
		}
		if (!empty($width) || !empty($height)) {
			$w = !empty($width) && strlen(intval($width)) == strlen($width) ? $width : null;
			$h = !empty($height) && strlen(intval($height)) == strlen($height) ? $height : null;
			if ($w || $h) $src = booklovers_get_resized_image_url($src, $w, $h);
		}
		if (trim($link)) booklovers_enqueue_popup();
		$output = empty($src) ? '' : ('<figure' . ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ' class="sc_image ' . ($align && $align!='none' ? ' align' . esc_attr($align) : '') . (!empty($shape) ? ' sc_image_shape_'.esc_attr($shape) : '') . (!empty($class) ? ' '.esc_attr($class) : '') . '"'
			. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
			. '>'
				. (trim($link) ? '<a href="'.esc_url($link).'">' : '')
				. '<img src="'.esc_url($src).'" alt="" />'
				. (trim($link) ? '</a>' : '')
				. (trim($title) || trim($icon) ? '<figcaption><span'.($icon ? ' class="'.esc_attr($icon).'"' : '').'></span> ' . ($title) . '</figcaption>' : '')
			. '</figure>');
		return apply_filters('booklovers_shortcode_output', $output, 'trx_image', $atts, $content);
	}
	booklovers_require_shortcode('trx_image', 'booklovers_sc_image');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_image_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_image_reg_shortcodes');
	function booklovers_sc_image_reg_shortcodes() {
	
		booklovers_sc_map("trx_image", array(
			"title" => esc_html__("Image", 'booklovers'),
			"desc" => wp_kses_data( __("Insert image into your post (page)", 'booklovers') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"url" => array(
					"title" => esc_html__("URL for image file", 'booklovers'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site", 'booklovers') ),
					"readonly" => false,
					"value" => "",
					"type" => "media",
					"before" => array(
						'sizes' => true		// If you want allow user select thumb size for image. Otherwise, thumb size is ignored - image fullsize used
					)
				),
				"title" => array(
					"title" => esc_html__("Title", 'booklovers'),
					"desc" => wp_kses_data( __("Image title (if need)", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"icon" => array(
					"title" => esc_html__("Icon before title",  'booklovers'),
					"desc" => wp_kses_data( __('Select icon for the title from Fontello icons set',  'booklovers') ),
					"value" => "",
					"type" => "icons",
					"options" => booklovers_get_sc_param('icons')
				),
				"align" => array(
					"title" => esc_html__("Float image", 'booklovers'),
					"desc" => wp_kses_data( __("Float image to left or right side", 'booklovers') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => booklovers_get_sc_param('float')
				), 
				"shape" => array(
					"title" => esc_html__("Image Shape", 'booklovers'),
					"desc" => wp_kses_data( __("Shape of the image: square (rectangle) or round", 'booklovers') ),
					"value" => "square",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						"square" => esc_html__('Square', 'booklovers'),
						"round" => esc_html__('Round', 'booklovers')
					)
				), 
				"link" => array(
					"title" => esc_html__("Link", 'booklovers'),
					"desc" => wp_kses_data( __("The link URL from the image", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"shadow" => array(
					"title" => esc_html__("Add shasow", 'booklovers'),
					"desc" => wp_kses_data( __("Add shadow arround image", 'booklovers') ),
					"value" => "no",
					"type" => "switch",
					"options" => booklovers_get_sc_param('yes_no')
				),
				"width" => booklovers_shortcodes_width(),
				"height" => booklovers_shortcodes_height(),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_image_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_image_reg_shortcodes_vc');
	function booklovers_sc_image_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_image",
			"name" => esc_html__("Image", 'booklovers'),
			"description" => wp_kses_data( __("Insert image", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_image',
			"class" => "trx_sc_single trx_sc_image",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "url",
					"heading" => esc_html__("Select image", 'booklovers'),
					"description" => wp_kses_data( __("Select image from library", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Image alignment", 'booklovers'),
					"description" => wp_kses_data( __("Align image to left or right side", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(booklovers_get_sc_param('float')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "shape",
					"heading" => esc_html__("Image shape", 'booklovers'),
					"description" => wp_kses_data( __("Shape of the image: square or round", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Square', 'booklovers') => 'square',
						esc_html__('Round', 'booklovers') => 'round'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'booklovers'),
					"description" => wp_kses_data( __("Image's title", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Title's icon", 'booklovers'),
					"description" => wp_kses_data( __("Select icon for the title from Fontello icons set", 'booklovers') ),
					"class" => "",
					"value" => booklovers_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Link", 'booklovers'),
					"description" => wp_kses_data( __("The link URL from the image", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "shadow",
					"heading" => esc_html__("Add shadow", 'booklovers'),
					"description" => wp_kses_data( __("Add shadow arround image", 'booklovers') ),
					"class" => "",
					"value" => array(esc_html__('Shadow', 'booklovers') => 'yes'),
					"type" => "checkbox"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_vc_width(),
				booklovers_vc_height(),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Image extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>