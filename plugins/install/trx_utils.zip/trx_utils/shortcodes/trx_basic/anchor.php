<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_anchor_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_anchor_theme_setup' );
	function booklovers_sc_anchor_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_anchor_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_anchor_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_anchor id="unique_id" description="Anchor description" title="Short Caption" icon="icon-class"]
*/

if (!function_exists('booklovers_sc_anchor')) {	
	function booklovers_sc_anchor($atts, $content = null) {
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"description" => '',
			"icon" => '',
			"url" => "",
			"separator" => "no",
			// Common params
			"id" => ""
		), $atts)));
		$output = $id 
			? '<a id="'.esc_attr($id).'"'
				. ' class="sc_anchor"' 
				. ' title="' . ($title ? esc_attr($title) : '') . '"'
				. ' data-description="' . ($description ? esc_attr(booklovers_strmacros($description)) : ''). '"'
				. ' data-icon="' . ($icon ? $icon : '') . '"' 
				. ' data-url="' . ($url ? esc_attr($url) : '') . '"' 
				. ' data-separator="' . (booklovers_param_is_on($separator) ? 'yes' : 'no') . '"'
				. '></a>'
			: '';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_anchor', $atts, $content);
	}
	booklovers_require_shortcode("trx_anchor", "booklovers_sc_anchor");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_anchor_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_anchor_reg_shortcodes');
	function booklovers_sc_anchor_reg_shortcodes() {
	
		booklovers_sc_map("trx_anchor", array(
			"title" => esc_html__("Anchor", 'booklovers'),
			"desc" => wp_kses_data( __("Insert anchor for the TOC (table of content)", 'booklovers') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"icon" => array(
					"title" => esc_html__("Anchor's icon",  'booklovers'),
					"desc" => wp_kses_data( __('Select icon for the anchor from Fontello icons set',  'booklovers') ),
					"value" => "",
					"type" => "icons",
					"options" => booklovers_get_sc_param('icons')
				),
				"title" => array(
					"title" => esc_html__("Short title", 'booklovers'),
					"desc" => wp_kses_data( __("Short title of the anchor (for the table of content)", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"description" => array(
					"title" => esc_html__("Long description", 'booklovers'),
					"desc" => wp_kses_data( __("Description for the popup (then hover on the icon). You can use:<br>'{{' and '}}' - to make the text italic,<br>'((' and '))' - to make the text bold,<br>'||' - to insert line break", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"url" => array(
					"title" => esc_html__("External URL", 'booklovers'),
					"desc" => wp_kses_data( __("External URL for this TOC item", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"separator" => array(
					"title" => esc_html__("Add separator", 'booklovers'),
					"desc" => wp_kses_data( __("Add separator under item in the TOC", 'booklovers') ),
					"value" => "no",
					"type" => "switch",
					"options" => booklovers_get_sc_param('yes_no')
				),
				"id" => booklovers_get_sc_param('id')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_anchor_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_anchor_reg_shortcodes_vc');
	function booklovers_sc_anchor_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_anchor",
			"name" => esc_html__("Anchor", 'booklovers'),
			"description" => wp_kses_data( __("Insert anchor for the TOC (table of content)", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_anchor',
			"class" => "trx_sc_single trx_sc_anchor",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Anchor's icon", 'booklovers'),
					"description" => wp_kses_data( __("Select icon for the anchor from Fontello icons set", 'booklovers') ),
					"class" => "",
					"value" => booklovers_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Short title", 'booklovers'),
					"description" => wp_kses_data( __("Short title of the anchor (for the table of content)", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "description",
					"heading" => esc_html__("Long description", 'booklovers'),
					"description" => wp_kses_data( __("Description for the popup (then hover on the icon). You can use:<br>'{{' and '}}' - to make the text italic,<br>'((' and '))' - to make the text bold,<br>'||' - to insert line break", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "url",
					"heading" => esc_html__("External URL", 'booklovers'),
					"description" => wp_kses_data( __("External URL for this TOC item", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "separator",
					"heading" => esc_html__("Add separator", 'booklovers'),
					"description" => wp_kses_data( __("Add separator under item in the TOC", 'booklovers') ),
					"class" => "",
					"value" => array("Add separator" => "yes" ),
					"type" => "checkbox"
				),
				booklovers_get_vc_param('id')
			),
		) );
		
		class WPBakeryShortCode_Trx_Anchor extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>