<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_reviews_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_reviews_theme_setup' );
	function booklovers_sc_reviews_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_reviews_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_reviews_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_reviews]
*/

if (!function_exists('booklovers_sc_reviews')) {	
	function booklovers_sc_reviews($atts, $content = null) {
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"align" => "right",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$output = booklovers_param_is_off(booklovers_get_custom_option('show_sidebar_main'))
			? '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
						. ' class="sc_reviews'
							. ($align && $align!='none' ? ' align'.esc_attr($align) : '')
							. ($class ? ' '.esc_attr($class) : '')
							. '"'
						. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
						. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
						. '>'
					. trim(booklovers_get_reviews_placeholder())
					. '</div>'
			: '';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_reviews', $atts, $content);
	}
	booklovers_require_shortcode("trx_reviews", "booklovers_sc_reviews");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_reviews_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_reviews_reg_shortcodes');
	function booklovers_sc_reviews_reg_shortcodes() {
	
		booklovers_sc_map("trx_reviews", array(
			"title" => esc_html__("Reviews", 'booklovers'),
			"desc" => wp_kses_data( __("Insert reviews block in the single post", 'booklovers') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"align" => array(
					"title" => esc_html__("Alignment", 'booklovers'),
					"desc" => wp_kses_data( __("Align counter to left, center or right", 'booklovers') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => booklovers_get_sc_param('align')
				), 
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_reviews_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_reviews_reg_shortcodes_vc');
	function booklovers_sc_reviews_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_reviews",
			"name" => esc_html__("Reviews", 'booklovers'),
			"description" => wp_kses_data( __("Insert reviews block in the single post", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_reviews',
			"class" => "trx_sc_single trx_sc_reviews",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'booklovers'),
					"description" => wp_kses_data( __("Align counter to left, center or right", 'booklovers') ),
					"class" => "",
					"value" => array_flip(booklovers_get_sc_param('align')),
					"type" => "dropdown"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Reviews extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>