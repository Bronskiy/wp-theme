<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_infobox_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_infobox_theme_setup' );
	function booklovers_sc_infobox_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_infobox_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_infobox_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_infobox id="unique_id" style="regular|info|success|error|result" static="0|1"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_infobox]
*/

if (!function_exists('booklovers_sc_infobox')) {	
	function booklovers_sc_infobox($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"style" => "regular",
			"closeable" => "no",
			"icon" => "",
			"color" => "",
			"bg_color" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= ($color !== '' ? 'color:' . esc_attr($color) .';' : '')
			. ($bg_color !== '' ? 'background-color:' . esc_attr($bg_color) .';' : '');
		if (empty($icon)) {
			if ($icon=='none')
				$icon = '';
			else if ($style=='regular')
				$icon = 'icon-cog';
			else if ($style=='success')
				$icon = 'icon-check';
			else if ($style=='error')
				$icon = 'icon-attention';
			else if ($style=='info')
				$icon = 'icon-info';
		}
		$content = do_shortcode($content);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_infobox sc_infobox_style_' . esc_attr($style) 
					. (booklovers_param_is_on($closeable) ? ' sc_infobox_closeable' : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '') 
					. ($icon!='' && !booklovers_param_is_inherit($icon) ? ' sc_infobox_iconed '. esc_attr($icon) : '') 
					. '"'
				. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>'
				. trim($content)
				. '</div>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_infobox', $atts, $content);
	}
	booklovers_require_shortcode('trx_infobox', 'booklovers_sc_infobox');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_infobox_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_infobox_reg_shortcodes');
	function booklovers_sc_infobox_reg_shortcodes() {
	
		booklovers_sc_map("trx_infobox", array(
			"title" => esc_html__("Infobox", 'booklovers'),
			"desc" => wp_kses_data( __("Insert infobox into your post (page)", 'booklovers') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"style" => array(
					"title" => esc_html__("Style", 'booklovers'),
					"desc" => wp_kses_data( __("Infobox style", 'booklovers') ),
					"value" => "regular",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						'regular' => esc_html__('Regular', 'booklovers'),
						'info' => esc_html__('Info', 'booklovers'),
						'success' => esc_html__('Success', 'booklovers'),
						'error' => esc_html__('Error', 'booklovers')
					)
				),
				"closeable" => array(
					"title" => esc_html__("Closeable box", 'booklovers'),
					"desc" => wp_kses_data( __("Create closeable box (with close button)", 'booklovers') ),
					"value" => "no",
					"type" => "switch",
					"options" => booklovers_get_sc_param('yes_no')
				),
				"icon" => array(
					"title" => esc_html__("Custom icon",  'booklovers'),
					"desc" => wp_kses_data( __('Select icon for the infobox from Fontello icons set. If empty - use default icon',  'booklovers') ),
					"value" => "",
					"type" => "icons",
					"options" => booklovers_get_sc_param('icons')
				),
				"color" => array(
					"title" => esc_html__("Text color", 'booklovers'),
					"desc" => wp_kses_data( __("Any color for text and headers", 'booklovers') ),
					"value" => "",
					"type" => "color"
				),
				"bg_color" => array(
					"title" => esc_html__("Background color", 'booklovers'),
					"desc" => wp_kses_data( __("Any background color for this infobox", 'booklovers') ),
					"value" => "",
					"type" => "color"
				),
				"_content_" => array(
					"title" => esc_html__("Infobox content", 'booklovers'),
					"desc" => wp_kses_data( __("Content for infobox", 'booklovers') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_infobox_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_infobox_reg_shortcodes_vc');
	function booklovers_sc_infobox_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_infobox",
			"name" => esc_html__("Infobox", 'booklovers'),
			"description" => wp_kses_data( __("Box with info or error message", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_infobox',
			"class" => "trx_sc_container trx_sc_infobox",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "style",
					"heading" => esc_html__("Style", 'booklovers'),
					"description" => wp_kses_data( __("Infobox style", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
							esc_html__('Regular', 'booklovers') => 'regular',
							esc_html__('Info', 'booklovers') => 'info',
							esc_html__('Success', 'booklovers') => 'success',
							esc_html__('Error', 'booklovers') => 'error',
							esc_html__('Result', 'booklovers') => 'result'
						),
					"type" => "dropdown"
				),
				array(
					"param_name" => "closeable",
					"heading" => esc_html__("Closeable", 'booklovers'),
					"description" => wp_kses_data( __("Create closeable box (with close button)", 'booklovers') ),
					"class" => "",
					"value" => array(esc_html__('Close button', 'booklovers') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Custom icon", 'booklovers'),
					"description" => wp_kses_data( __("Select icon for the infobox from Fontello icons set. If empty - use default icon", 'booklovers') ),
					"class" => "",
					"value" => booklovers_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Text color", 'booklovers'),
					"description" => wp_kses_data( __("Any color for the text and headers", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Background color", 'booklovers'),
					"description" => wp_kses_data( __("Any background color for this infobox", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				/*
				array(
					"param_name" => "content",
					"heading" => esc_html__("Message text", 'booklovers'),
					"description" => wp_kses_data( __("Message for the infobox", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				*/
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextContainerView'
		) );
		
		class WPBakeryShortCode_Trx_Infobox extends BOOKLOVERS_VC_ShortCodeContainer {}
	}
}
?>