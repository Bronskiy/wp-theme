<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_quote_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_quote_theme_setup' );
	function booklovers_sc_quote_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_quote_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_quote_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_quote id="unique_id" cite="url" title=""]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/quote]
*/

if (!function_exists('booklovers_sc_quote')) {	
	function booklovers_sc_quote($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"style" =>"style-1",
			"cite" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= booklovers_get_css_dimensions_from_values($width);
		$cite_param = $cite != '' ? ' cite="'.esc_attr($cite).'"' : '';
		$title = $title=='' ? $cite : $title;
		$content = do_shortcode($content);
		if (booklovers_substr($content, 0, 2)!='<p') $content = '<p>' . ($content) . '</p>';
		$output = '<blockquote' 
			. ($id ? ' id="'.esc_attr($id).'"' : '') . ($cite_param) 
			. ' class="sc_quote'. (!empty($class) ? ' '.esc_attr($class) : ''). (!empty($style) ? ' '.esc_attr($style) : '').'"' 
			. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
			. '>'
				. ($content)
				. ($title == '' ? '' : ('<p class="sc_quote_title">' . ($cite!='' ? '<a href="'.esc_url($cite).'">' : '') . ($title) . ($cite!='' ? '</a>' : '') . '</p>'))
			.'</blockquote>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_quote', $atts, $content);
	}
	booklovers_require_shortcode('trx_quote', 'booklovers_sc_quote');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_quote_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_quote_reg_shortcodes');
	function booklovers_sc_quote_reg_shortcodes() {
	
		booklovers_sc_map("trx_quote", array(
			"title" => esc_html__("Quote", 'booklovers'),
			"desc" => wp_kses_data( __("Quote text", 'booklovers') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"cite" => array(
					"title" => esc_html__("Quote cite", 'booklovers'),
					"desc" => wp_kses_data( __("URL for quote cite", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"style" => array(
					"title" => esc_html__("Quote style", 'booklovers'),
					"desc" => wp_kses_data( __("Choose quote style", 'booklovers') ),
					"value" => "",
					"type" => "select",
					"options" => array(
						'style_1' => esc_html('Style 1','booklovers'),
						'style_2' => esc_html('Style 2','booklovers')
						)
				),
				"title" => array(
					"title" => esc_html__("Title (author)", 'booklovers'),
					"desc" => wp_kses_data( __("Quote title (author name)", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"_content_" => array(
					"title" => esc_html__("Quote content", 'booklovers'),
					"desc" => wp_kses_data( __("Quote content", 'booklovers') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"width" => booklovers_shortcodes_width(),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_quote_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_quote_reg_shortcodes_vc');
	function booklovers_sc_quote_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_quote",
			"name" => esc_html__("Quote", 'booklovers'),
			"description" => wp_kses_data( __("Quote text", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_quote',
			"class" => "trx_sc_single trx_sc_quote",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "cite",
					"heading" => esc_html__("Quote cite", 'booklovers'),
					"description" => wp_kses_data( __("URL for the quote cite link", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Quote style", 'booklovers'),
					"description" => wp_kses_data( __("Choose quote style", 'booklovers') ),
					"class" => "",
					"value" => array(
							esc_html__('Style 1', 'booklovers') => 'style_1',
							esc_html__('Style 2', 'booklovers') => 'style_2',
						),
					"type" => "dropdown"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title (author)", 'booklovers'),
					"description" => wp_kses_data( __("Quote title (author name)", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "content",
					"heading" => esc_html__("Quote content", 'booklovers'),
					"description" => wp_kses_data( __("Quote content", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_vc_width(),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Quote extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>