<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_title_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_title_theme_setup' );
	function booklovers_sc_title_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_title_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_title_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_title id="unique_id" style='regular|iconed' icon='' image='' background="on|off" type="1-6"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_title]
*/

if (!function_exists('booklovers_sc_title')) {	
	function booklovers_sc_title($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"type" => "1",
			"style" => "regular",
			"align" => "",
			"font_weight" => "",
			"font_size" => "",
			"color" => "",
			"icon" => "",
			"image" => "",
			"picture" => "",
			"image_size" => "small",
			"position" => "left",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= booklovers_get_css_dimensions_from_values($width)
			.($align && $align!='none' && !booklovers_param_is_inherit($align) ? 'text-align:' . esc_attr($align) .';' : '')
			.($color ? 'color:' . esc_attr($color) .';' : '')
			.($font_weight && !booklovers_param_is_inherit($font_weight) ? 'font-weight:' . esc_attr($font_weight) .';' : '')
			.($font_size   ? 'font-size:' . esc_attr($font_size) .';' : '')
			;
		$type = min(6, max(1, $type));
		if ($picture > 0) {
			$attach = wp_get_attachment_image_src( $picture, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$picture = $attach[0];
		}
		$pic = $style!='iconed' 
			? '' 
			: '<span class="sc_title_icon sc_title_icon_'.esc_attr($position).'  sc_title_icon_'.esc_attr($image_size).($icon!='' && $icon!='none' ? ' '.esc_attr($icon) : '').'"'.'>'
				.($picture ? '<img src="'.esc_url($picture).'" alt="" />' : '')
				.(empty($picture) && $image && $image!='none' ? '<img src="'.esc_url(booklovers_strpos($image, 'http:')!==false ? $image : booklovers_get_file_url('images/icons/'.($image).'.png')).'" alt="" />' : '')
				.'</span>';
		$output = '<h' . esc_attr($type) . ($id ? ' id="'.esc_attr($id).'"' : '')
				. ' class="sc_title sc_title_'.esc_attr($style)
					.($align && $align!='none' && !booklovers_param_is_inherit($align) ? ' sc_align_' . esc_attr($align) : '')
					.(!empty($class) ? ' '.esc_attr($class) : '')
					.'"'
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
				. '>'
					. ($pic)
					. ($style=='divider' ? '<span class="sc_title_divider_before"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
					. do_shortcode($content) 
					. ($style=='divider' ? '<span class="sc_title_divider_after"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
				. '</h' . esc_attr($type) . '>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_title', $atts, $content);
	}
	booklovers_require_shortcode('trx_title', 'booklovers_sc_title');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_title_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_title_reg_shortcodes');
	function booklovers_sc_title_reg_shortcodes() {
	
		booklovers_sc_map("trx_title", array(
			"title" => esc_html__("Title", 'booklovers'),
			"desc" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'booklovers') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Title content", 'booklovers'),
					"desc" => wp_kses_data( __("Title content", 'booklovers') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"type" => array(
					"title" => esc_html__("Title type", 'booklovers'),
					"desc" => wp_kses_data( __("Title type (header level)", 'booklovers') ),
					"divider" => true,
					"value" => "1",
					"type" => "select",
					"options" => array(
						'1' => esc_html__('Header 1', 'booklovers'),
						'2' => esc_html__('Header 2', 'booklovers'),
						'3' => esc_html__('Header 3', 'booklovers'),
						'4' => esc_html__('Header 4', 'booklovers'),
						'5' => esc_html__('Header 5', 'booklovers'),
						'6' => esc_html__('Header 6', 'booklovers'),
					)
				),
				"style" => array(
					"title" => esc_html__("Title style", 'booklovers'),
					"desc" => wp_kses_data( __("Title style", 'booklovers') ),
					"value" => "regular",
					"type" => "select",
					"options" => array(
						'regular' => esc_html__('Regular', 'booklovers'),
						'underline' => esc_html__('Underline', 'booklovers'),
						'divider' => esc_html__('Divider', 'booklovers'),
						'iconed' => esc_html__('With icon (image)', 'booklovers')
					)
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'booklovers'),
					"desc" => wp_kses_data( __("Title text alignment", 'booklovers') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => booklovers_get_sc_param('align')
				), 
				"font_size" => array(
					"title" => esc_html__("Font_size", 'booklovers'),
					"desc" => wp_kses_data( __("Custom font size. If empty - use theme default", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"font_weight" => array(
					"title" => esc_html__("Font weight", 'booklovers'),
					"desc" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'booklovers') ),
					"value" => "",
					"type" => "select",
					"size" => "medium",
					"options" => array(
						'inherit' => esc_html__('Default', 'booklovers'),
						'100' => esc_html__('Thin (100)', 'booklovers'),
						'300' => esc_html__('Light (300)', 'booklovers'),
						'400' => esc_html__('Normal (400)', 'booklovers'),
						'600' => esc_html__('Semibold (600)', 'booklovers'),
						'700' => esc_html__('Bold (700)', 'booklovers'),
						'900' => esc_html__('Black (900)', 'booklovers')
					)
				),
				"color" => array(
					"title" => esc_html__("Title color", 'booklovers'),
					"desc" => wp_kses_data( __("Select color for the title", 'booklovers') ),
					"value" => "",
					"type" => "color"
				),
				"icon" => array(
					"title" => esc_html__('Title font icon',  'booklovers'),
					"desc" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)",  'booklovers') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "icons",
					"options" => booklovers_get_sc_param('icons')
				),
				"image" => array(
					"title" => esc_html__('or image icon',  'booklovers'),
					"desc" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)",  'booklovers') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "images",
					"size" => "small",
					"options" => booklovers_get_sc_param('images')
				),
				"picture" => array(
					"title" => esc_html__('or URL for image file', 'booklovers'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'booklovers') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"image_size" => array(
					"title" => esc_html__('Image (picture) size', 'booklovers'),
					"desc" => wp_kses_data( __("Select image (picture) size (if style='iconed')", 'booklovers') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "small",
					"type" => "checklist",
					"options" => array(
						'small' => esc_html__('Small', 'booklovers'),
						'medium' => esc_html__('Medium', 'booklovers'),
						'large' => esc_html__('Large', 'booklovers')
					)
				),
				"position" => array(
					"title" => esc_html__('Icon (image) position', 'booklovers'),
					"desc" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'booklovers') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "left",
					"type" => "checklist",
					"options" => array(
						'top' => esc_html__('Top', 'booklovers'),
						'left' => esc_html__('Left', 'booklovers')
					)
				),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_title_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_title_reg_shortcodes_vc');
	function booklovers_sc_title_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_title",
			"name" => esc_html__("Title", 'booklovers'),
			"description" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_title',
			"class" => "trx_sc_single trx_sc_title",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "content",
					"heading" => esc_html__("Title content", 'booklovers'),
					"description" => wp_kses_data( __("Title content", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Title type", 'booklovers'),
					"description" => wp_kses_data( __("Title type (header level)", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Header 1', 'booklovers') => '1',
						esc_html__('Header 2', 'booklovers') => '2',
						esc_html__('Header 3', 'booklovers') => '3',
						esc_html__('Header 4', 'booklovers') => '4',
						esc_html__('Header 5', 'booklovers') => '5',
						esc_html__('Header 6', 'booklovers') => '6'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Title style", 'booklovers'),
					"description" => wp_kses_data( __("Title style: only text (regular) or with icon/image (iconed)", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Regular', 'booklovers') => 'regular',
						esc_html__('Underline', 'booklovers') => 'underline',
						esc_html__('Divider', 'booklovers') => 'divider',
						esc_html__('With icon (image)', 'booklovers') => 'iconed'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'booklovers'),
					"description" => wp_kses_data( __("Title text alignment", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(booklovers_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "font_size",
					"heading" => esc_html__("Font size", 'booklovers'),
					"description" => wp_kses_data( __("Custom font size. If empty - use theme default", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "font_weight",
					"heading" => esc_html__("Font weight", 'booklovers'),
					"description" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'booklovers') ),
					"class" => "",
					"value" => array(
						esc_html__('Default', 'booklovers') => 'inherit',
						esc_html__('Thin (100)', 'booklovers') => '100',
						esc_html__('Light (300)', 'booklovers') => '300',
						esc_html__('Normal (400)', 'booklovers') => '400',
						esc_html__('Semibold (600)', 'booklovers') => '600',
						esc_html__('Bold (700)', 'booklovers') => '700',
						esc_html__('Black (900)', 'booklovers') => '900'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Title color", 'booklovers'),
					"description" => wp_kses_data( __("Select color for the title", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Title font icon", 'booklovers'),
					"description" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'booklovers'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => booklovers_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("or image icon", 'booklovers'),
					"description" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'booklovers'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => booklovers_get_sc_param('images'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "picture",
					"heading" => esc_html__("or select uploaded image", 'booklovers'),
					"description" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'booklovers') ),
					"group" => esc_html__('Icon &amp; Image', 'booklovers'),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "image_size",
					"heading" => esc_html__("Image (picture) size", 'booklovers'),
					"description" => wp_kses_data( __("Select image (picture) size (if style=iconed)", 'booklovers') ),
					"group" => esc_html__('Icon &amp; Image', 'booklovers'),
					"class" => "",
					"value" => array(
						esc_html__('Small', 'booklovers') => 'small',
						esc_html__('Medium', 'booklovers') => 'medium',
						esc_html__('Large', 'booklovers') => 'large'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "position",
					"heading" => esc_html__("Icon (image) position", 'booklovers'),
					"description" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'booklovers') ),
					"group" => esc_html__('Icon &amp; Image', 'booklovers'),
					"class" => "",
					"std" => "left",
					"value" => array(
						esc_html__('Top', 'booklovers') => 'top',
						esc_html__('Left', 'booklovers') => 'left'
					),
					"type" => "dropdown"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Title extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>