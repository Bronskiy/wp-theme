<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_tooltip_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_tooltip_theme_setup' );
	function booklovers_sc_tooltip_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_tooltip_reg_shortcodes');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_tooltip id="unique_id" title="Tooltip text here"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/tooltip]
*/

if (!function_exists('booklovers_sc_tooltip')) {	
	function booklovers_sc_tooltip($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => ""
		), $atts)));
		$output = '<span' . ($id ? ' id="'.esc_attr($id).'"' : '') 
					. ' class="sc_tooltip_parent'. (!empty($class) ? ' '.esc_attr($class) : '').'"'
					. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
					. '>'
						. do_shortcode($content)
						. '<span class="sc_tooltip">' . ($title) . '</span>'
					. '</span>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_tooltip', $atts, $content);
	}
	booklovers_require_shortcode('trx_tooltip', 'booklovers_sc_tooltip');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_tooltip_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_tooltip_reg_shortcodes');
	function booklovers_sc_tooltip_reg_shortcodes() {
	
		booklovers_sc_map("trx_tooltip", array(
			"title" => esc_html__("Tooltip", 'booklovers'),
			"desc" => wp_kses_data( __("Create tooltip for selected text", 'booklovers') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"title" => array(
					"title" => esc_html__("Title", 'booklovers'),
					"desc" => wp_kses_data( __("Tooltip title (required)", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"_content_" => array(
					"title" => esc_html__("Tipped content", 'booklovers'),
					"desc" => wp_kses_data( __("Highlighted content with tooltip", 'booklovers') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}
?>