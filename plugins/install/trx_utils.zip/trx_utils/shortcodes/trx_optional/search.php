<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_search_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_search_theme_setup' );
	function booklovers_sc_search_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_search_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_search_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_search id="unique_id" open="yes|no"]
*/

if (!function_exists('booklovers_sc_search')) {	
	function booklovers_sc_search($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"style" => "regular",
			"state" => "fixed",
			"scheme" => "original",
			"ajax" => "",
			"title" => esc_html__('Search', 'booklovers'),
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		if (empty($ajax)) $ajax = booklovers_get_theme_option('use_ajax_search');
		// Load core messages
		booklovers_enqueue_messages();
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') . ' class="search_wrap search_style_'.esc_attr($style).' search_state_'.esc_attr($state)
						. (booklovers_param_is_on($ajax) ? ' search_ajax' : '')
						. ($class ? ' '.esc_attr($class) : '')
						. '"'
					. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
					. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
					. '>
						<div class="search_form_wrap">
							<form role="search" method="get" class="search_form" action="' . esc_url(home_url('/')) . '">
								<button type="submit" class="search_submit icon-search" data-content="'.esc_attr__('search','booklovers').'" title="' . ($state=='closed' ? esc_attr__('Open search', 'booklovers') : esc_attr__('Start search', 'booklovers')) . '"></button>
								<input type="text" class="search_field" placeholder="' . esc_attr($title) . '" value="' . esc_attr(get_search_query()) . '" name="s" />
							</form>
						</div>
						<div class="search_results widget_area' . ($scheme && !booklovers_param_is_off($scheme) && !booklovers_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '') . '"><a class="search_results_close icon-cancel"></a><div class="search_results_content"></div></div>
				</div>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_search', $atts, $content);
	}
	booklovers_require_shortcode('trx_search', 'booklovers_sc_search');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_search_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_search_reg_shortcodes');
	function booklovers_sc_search_reg_shortcodes() {
	
		booklovers_sc_map("trx_search", array(
			"title" => esc_html__("Search", 'booklovers'),
			"desc" => wp_kses_data( __("Show search form", 'booklovers') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"style" => array(
					"title" => esc_html__("Style", 'booklovers'),
					"desc" => wp_kses_data( __("Select style to display search field", 'booklovers') ),
					"value" => "regular",
					"options" => array(
						"regular" => esc_html__('Regular', 'booklovers'),
						"rounded" => esc_html__('Rounded', 'booklovers')
					),
					"type" => "checklist"
				),
				"state" => array(
					"title" => esc_html__("State", 'booklovers'),
					"desc" => wp_kses_data( __("Select search field initial state", 'booklovers') ),
					"value" => "fixed",
					"options" => array(
						"fixed"  => esc_html__('Fixed',  'booklovers'),
						"opened" => esc_html__('Opened', 'booklovers'),
						"closed" => esc_html__('Closed', 'booklovers')
					),
					"type" => "checklist"
				),
				"title" => array(
					"title" => esc_html__("Title", 'booklovers'),
					"desc" => wp_kses_data( __("Title (placeholder) for the search field", 'booklovers') ),
					"value" => esc_html__("Search &hellip;", 'booklovers'),
					"type" => "text"
				),
				"ajax" => array(
					"title" => esc_html__("AJAX", 'booklovers'),
					"desc" => wp_kses_data( __("Search via AJAX or reload page", 'booklovers') ),
					"value" => "yes",
					"options" => booklovers_get_sc_param('yes_no'),
					"type" => "switch"
				),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_search_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_search_reg_shortcodes_vc');
	function booklovers_sc_search_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_search",
			"name" => esc_html__("Search form", 'booklovers'),
			"description" => wp_kses_data( __("Insert search form", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_search',
			"class" => "trx_sc_single trx_sc_search",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "style",
					"heading" => esc_html__("Style", 'booklovers'),
					"description" => wp_kses_data( __("Select style to display search field", 'booklovers') ),
					"class" => "",
					"value" => array(
						esc_html__('Regular', 'booklovers') => "regular",
						esc_html__('Flat', 'booklovers') => "flat"
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "state",
					"heading" => esc_html__("State", 'booklovers'),
					"description" => wp_kses_data( __("Select search field initial state", 'booklovers') ),
					"class" => "",
					"value" => array(
						esc_html__('Fixed', 'booklovers')  => "fixed",
						esc_html__('Opened', 'booklovers') => "opened",
						esc_html__('Closed', 'booklovers') => "closed"
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'booklovers'),
					"description" => wp_kses_data( __("Title (placeholder) for the search field", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => esc_html__("Search &hellip;", 'booklovers'),
					"type" => "textfield"
				),
				array(
					"param_name" => "ajax",
					"heading" => esc_html__("AJAX", 'booklovers'),
					"description" => wp_kses_data( __("Search via AJAX or reload page", 'booklovers') ),
					"class" => "",
					"value" => array(esc_html__('Use AJAX search', 'booklovers') => 'yes'),
					"type" => "checkbox"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Search extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>