<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_button_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_button_theme_setup' );
	function booklovers_sc_button_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_button_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_button_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_button id="unique_id" type="square|round" fullsize="0|1" style="global|light|dark" size="mini|medium|big|huge|banner" icon="icon-name" link='#' target='']Button caption[/trx_button]
*/

if (!function_exists('booklovers_sc_button')) {	
	function booklovers_sc_button($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"type" => "square",
			"style" => "filled",
			"size" => "small",
			"icon" => "",
			"color" => "",
			"bg_color" => "",
			"link" => "",
			"target" => "",
			"align" => "",
			"rel" => "",
			"popup" => "no",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= booklovers_get_css_dimensions_from_values($width, $height)
			. ($color !== '' ? 'color:' . esc_attr($color) .';' : '')
			. ($bg_color !== '' ? 'background-color:' . esc_attr($bg_color) . '; border-color:'. esc_attr($bg_color) .';' : '');
		if (booklovers_param_is_on($popup)) booklovers_enqueue_popup('magnific');
		$output = '<a href="' . (empty($link) ? '#' : $link) . '"'
			. (!empty($target) ? ' target="'.esc_attr($target).'"' : '')
			. (!empty($rel) ? ' rel="'.esc_attr($rel).'"' : '')
			. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
			. ' class="sc_button sc_button_' . esc_attr($type) 
					. ' sc_button_style_' . esc_attr($style) 
					. ' sc_button_size_' . esc_attr($size)
					. ($align && $align!='none' ? ' align'.esc_attr($align) : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. ($icon!='' ? '  sc_button_iconed '. esc_attr($icon) : '') 
					. (booklovers_param_is_on($popup) ? ' sc_popup_link' : '') 
					. '"'
			. ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
			. '>'
			. do_shortcode($content)
			. '</a>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_button', $atts, $content);
	}
	booklovers_require_shortcode('trx_button', 'booklovers_sc_button');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_button_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_button_reg_shortcodes');
	function booklovers_sc_button_reg_shortcodes() {
	
		booklovers_sc_map("trx_button", array(
			"title" => esc_html__("Button", 'booklovers'),
			"desc" => wp_kses_data( __("Button with link", 'booklovers') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Caption", 'booklovers'),
					"desc" => wp_kses_data( __("Button caption", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"type" => array(
					"title" => esc_html__("Button's shape", 'booklovers'),
					"desc" => wp_kses_data( __("Select button's shape", 'booklovers') ),
					"value" => "square",
					"size" => "medium",
					"options" => array(
						'square' => esc_html__('Square', 'booklovers'),
						'round' => esc_html__('Round', 'booklovers')
					),
					"type" => "switch"
				), 
				"style" => array(
					"title" => esc_html__("Button's style", 'booklovers'),
					"desc" => wp_kses_data( __("Select button's style", 'booklovers') ),
					"value" => "default",
					"dir" => "horizontal",
					"options" => array(
						'filled' => esc_html__('Filled', 'booklovers'),
						'border' => esc_html__('Border', 'booklovers')
					),
					"type" => "checklist"
				), 
				"size" => array(
					"title" => esc_html__("Button's size", 'booklovers'),
					"desc" => wp_kses_data( __("Select button's size", 'booklovers') ),
					"value" => "small",
					"dir" => "horizontal",
					"options" => array(
						'small' => esc_html__('Small', 'booklovers'),
						'medium' => esc_html__('Medium', 'booklovers'),
						'large' => esc_html__('Large', 'booklovers')
					),
					"type" => "checklist"
				), 
				"icon" => array(
					"title" => esc_html__("Button's icon",  'booklovers'),
					"desc" => wp_kses_data( __('Select icon for the title from Fontello icons set',  'booklovers') ),
					"value" => "",
					"type" => "icons",
					"options" => booklovers_get_sc_param('icons')
				),
				"color" => array(
					"title" => esc_html__("Button's text color", 'booklovers'),
					"desc" => wp_kses_data( __("Any color for button's caption", 'booklovers') ),
					"std" => "",
					"value" => "",
					"type" => "color"
				),
				"bg_color" => array(
					"title" => esc_html__("Button's backcolor", 'booklovers'),
					"desc" => wp_kses_data( __("Any color for button's background", 'booklovers') ),
					"value" => "",
					"type" => "color"
				),
				"align" => array(
					"title" => esc_html__("Button's alignment", 'booklovers'),
					"desc" => wp_kses_data( __("Align button to left, center or right", 'booklovers') ),
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => booklovers_get_sc_param('align')
				), 
				"link" => array(
					"title" => esc_html__("Link URL", 'booklovers'),
					"desc" => wp_kses_data( __("URL for link on button click", 'booklovers') ),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"target" => array(
					"title" => esc_html__("Link target", 'booklovers'),
					"desc" => wp_kses_data( __("Target for link on button click", 'booklovers') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "",
					"type" => "text"
				),
				"popup" => array(
					"title" => esc_html__("Open link in popup", 'booklovers'),
					"desc" => wp_kses_data( __("Open link target in popup window", 'booklovers') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "no",
					"type" => "switch",
					"options" => booklovers_get_sc_param('yes_no')
				), 
				"rel" => array(
					"title" => esc_html__("Rel attribute", 'booklovers'),
					"desc" => wp_kses_data( __("Rel attribute for button's link (if need)", 'booklovers') ),
					"dependency" => array(
						'link' => array('not_empty')
					),
					"value" => "",
					"type" => "text"
				),
				"width" => booklovers_shortcodes_width(),
				"height" => booklovers_shortcodes_height(),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_button_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_button_reg_shortcodes_vc');
	function booklovers_sc_button_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_button",
			"name" => esc_html__("Button", 'booklovers'),
			"description" => wp_kses_data( __("Button with link", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			'icon' => 'icon_trx_button',
			"class" => "trx_sc_single trx_sc_button",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "content",
					"heading" => esc_html__("Caption", 'booklovers'),
					"description" => wp_kses_data( __("Button caption", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Button's shape", 'booklovers'),
					"description" => wp_kses_data( __("Select button's shape", 'booklovers') ),
					"class" => "",
					"value" => array(
						esc_html__('Square', 'booklovers') => 'square',
						esc_html__('Round', 'booklovers') => 'round'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Button's style", 'booklovers'),
					"description" => wp_kses_data( __("Select button's style", 'booklovers') ),
					"class" => "",
					"value" => array(
						esc_html__('Filled', 'booklovers') => 'filled',
						esc_html__('Border', 'booklovers') => 'border'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "size",
					"heading" => esc_html__("Button's size", 'booklovers'),
					"description" => wp_kses_data( __("Select button's size", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Small', 'booklovers') => 'small',
						esc_html__('Medium', 'booklovers') => 'medium',
						esc_html__('Large', 'booklovers') => 'large'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Button's icon", 'booklovers'),
					"description" => wp_kses_data( __("Select icon for the title from Fontello icons set", 'booklovers') ),
					"class" => "",
					"value" => booklovers_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Button's text color", 'booklovers'),
					"description" => wp_kses_data( __("Any color for button's caption", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Button's backcolor", 'booklovers'),
					"description" => wp_kses_data( __("Any color for button's background", 'booklovers') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Button's alignment", 'booklovers'),
					"description" => wp_kses_data( __("Align button to left, center or right", 'booklovers') ),
					"class" => "",
					"value" => array_flip(booklovers_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Link URL", 'booklovers'),
					"description" => wp_kses_data( __("URL for the link on button click", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Link', 'booklovers'),
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "target",
					"heading" => esc_html__("Link target", 'booklovers'),
					"description" => wp_kses_data( __("Target for the link on button click", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Link', 'booklovers'),
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "popup",
					"heading" => esc_html__("Open link in popup", 'booklovers'),
					"description" => wp_kses_data( __("Open link target in popup window", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Link', 'booklovers'),
					"value" => array(esc_html__('Open in popup', 'booklovers') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "rel",
					"heading" => esc_html__("Rel attribute", 'booklovers'),
					"description" => wp_kses_data( __("Rel attribute for the button's link (if need", 'booklovers') ),
					"class" => "",
					"group" => esc_html__('Link', 'booklovers'),
					"value" => "",
					"type" => "textfield"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_vc_width(),
				booklovers_vc_height(),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Button extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>