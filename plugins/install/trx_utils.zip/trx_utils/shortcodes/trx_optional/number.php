<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('booklovers_sc_number_theme_setup')) {
	add_action( 'booklovers_action_before_init_theme', 'booklovers_sc_number_theme_setup' );
	function booklovers_sc_number_theme_setup() {
		add_action('booklovers_action_shortcodes_list', 		'booklovers_sc_number_reg_shortcodes');
		if (function_exists('booklovers_exists_visual_composer') && booklovers_exists_visual_composer())
			add_action('booklovers_action_shortcodes_list_vc','booklovers_sc_number_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_number id="unique_id" value="400"]
*/

if (!function_exists('booklovers_sc_number')) {	
	function booklovers_sc_number($atts, $content=null){	
		if (booklovers_in_shortcode_blogger()) return '';
		extract(booklovers_html_decode(shortcode_atts(array(
			// Individual params
			"value" => "",
			"align" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . booklovers_get_css_position_as_classes($top, $right, $bottom, $left);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_number' 
					. (!empty($align) ? ' align'.esc_attr($align) : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '') 
					. '"'
				. (!booklovers_param_is_off($animation) ? ' data-animation="'.esc_attr(booklovers_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>';
		for ($i=0; $i < booklovers_strlen($value); $i++) {
			$output .= '<span class="sc_number_item">' . trim(booklovers_substr($value, $i, 1)) . '</span>';
		}
		$output .= '</div>';
		return apply_filters('booklovers_shortcode_output', $output, 'trx_number', $atts, $content);
	}
	booklovers_require_shortcode('trx_number', 'booklovers_sc_number');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_number_reg_shortcodes' ) ) {
	//add_action('booklovers_action_shortcodes_list', 'booklovers_sc_number_reg_shortcodes');
	function booklovers_sc_number_reg_shortcodes() {
	
		booklovers_sc_map("trx_number", array(
			"title" => esc_html__("Number", 'booklovers'),
			"desc" => wp_kses_data( __("Insert number or any word as set separate characters", 'booklovers') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"value" => array(
					"title" => esc_html__("Value", 'booklovers'),
					"desc" => wp_kses_data( __("Number or any word", 'booklovers') ),
					"value" => "",
					"type" => "text"
				),
				"align" => array(
					"title" => esc_html__("Align", 'booklovers'),
					"desc" => wp_kses_data( __("Select block alignment", 'booklovers') ),
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => booklovers_get_sc_param('align')
				),
				"top" => booklovers_get_sc_param('top'),
				"bottom" => booklovers_get_sc_param('bottom'),
				"left" => booklovers_get_sc_param('left'),
				"right" => booklovers_get_sc_param('right'),
				"id" => booklovers_get_sc_param('id'),
				"class" => booklovers_get_sc_param('class'),
				"animation" => booklovers_get_sc_param('animation'),
				"css" => booklovers_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'booklovers_sc_number_reg_shortcodes_vc' ) ) {
	//add_action('booklovers_action_shortcodes_list_vc', 'booklovers_sc_number_reg_shortcodes_vc');
	function booklovers_sc_number_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_number",
			"name" => esc_html__("Number", 'booklovers'),
			"description" => wp_kses_data( __("Insert number or any word as set of separated characters", 'booklovers') ),
			"category" => esc_html__('Content', 'booklovers'),
			"class" => "trx_sc_single trx_sc_number",
			'icon' => 'icon_trx_number',
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "value",
					"heading" => esc_html__("Value", 'booklovers'),
					"description" => wp_kses_data( __("Number or any word to separate", 'booklovers') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'booklovers'),
					"description" => wp_kses_data( __("Select block alignment", 'booklovers') ),
					"class" => "",
					"value" => array_flip(booklovers_get_sc_param('align')),
					"type" => "dropdown"
				),
				booklovers_get_vc_param('id'),
				booklovers_get_vc_param('class'),
				booklovers_get_vc_param('animation'),
				booklovers_get_vc_param('css'),
				booklovers_get_vc_param('margin_top'),
				booklovers_get_vc_param('margin_bottom'),
				booklovers_get_vc_param('margin_left'),
				booklovers_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Number extends BOOKLOVERS_VC_ShortCodeSingle {}
	}
}
?>